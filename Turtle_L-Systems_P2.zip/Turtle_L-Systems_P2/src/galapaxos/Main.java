package galapaxos;

import java.util.Scanner;
import java.util.Vector;

public class Main {

    public static void main(String [] args){
        KochCurve charMult = new KochCurve();
        Compiler comp = new Compiler();

        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();

        charMult.setStart("F");
        charMult.addRule('F', "F+F-F-F+F");
        String word = charMult.loopIter(n);
        System.out.println(word);

        comp.addRule('F', new Forward(1));
        comp.addRule('+', new Turn(90));
        comp.addRule('-', new Turn(-90));

        System.out.println(comp.compile(word));

    }
}
