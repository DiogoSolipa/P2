package galapaxos;

public class InterpreterClass {
}
